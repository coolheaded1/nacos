"use strict";

jQuery(document).ready(function($){
    //your custom js code here

});


